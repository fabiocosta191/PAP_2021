﻿
namespace PAP
{
    partial class Frm_ajuda
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_website = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_website
            // 
            this.btn_website.Location = new System.Drawing.Point(197, 189);
            this.btn_website.Name = "btn_website";
            this.btn_website.Size = new System.Drawing.Size(187, 69);
            this.btn_website.TabIndex = 0;
            this.btn_website.Text = "WebSite";
            this.btn_website.UseVisualStyleBackColor = true;
            this.btn_website.Click += new System.EventHandler(this.btn_website_Click);
            // 
            // Frm_ajuda
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_website);
            this.Name = "Frm_ajuda";
            this.Text = "Menu Principal | Menu Ajuda";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_website;
    }
}