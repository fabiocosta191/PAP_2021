﻿
namespace PAP
{
    partial class Frm_MenuPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm_MenuPrincipal));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.registarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.alunoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.professoresToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.livrosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tabletToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.filmesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.computadorToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.pesquisarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.alunoToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.professorToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.livroToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tabletToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.filmeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.movimentosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.requisiçãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.livrosToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.computadoresToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tabletsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.relatoriosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.livrosToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.computadoresToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.tabletsToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.relatórioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.alunoToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.professorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.livroToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.tabletToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.computadorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.filmeToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ferramentasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.backupToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tecnesaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.emailToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ajudaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.websiteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contactoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sugestõesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.terminarSessãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.sairToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.minimizarToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuPrincipalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.menuStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.Control;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(36, 36);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.registarToolStripMenuItem,
            this.pesquisarToolStripMenuItem,
            this.movimentosToolStripMenuItem,
            this.relatórioToolStripMenuItem,
            this.ferramentasToolStripMenuItem,
            this.toolStripMenuItem1,
            this.ajudaToolStripMenuItem,
            this.terminarSessãoToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1360, 59);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // registarToolStripMenuItem
            // 
            this.registarToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.alunoToolStripMenuItem,
            this.professoresToolStripMenuItem,
            this.livrosToolStripMenuItem,
            this.tabletToolStripMenuItem,
            this.filmesToolStripMenuItem,
            this.computadorToolStripMenuItem1});
            this.registarToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("registarToolStripMenuItem.Image")));
            this.registarToolStripMenuItem.Name = "registarToolStripMenuItem";
            this.registarToolStripMenuItem.Size = new System.Drawing.Size(61, 55);
            this.registarToolStripMenuItem.Text = "Registar";
            this.registarToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.registarToolStripMenuItem.Click += new System.EventHandler(this.registarToolStripMenuItem_Click);
            // 
            // alunoToolStripMenuItem
            // 
            this.alunoToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("alunoToolStripMenuItem.Image")));
            this.alunoToolStripMenuItem.Name = "alunoToolStripMenuItem";
            this.alunoToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.alunoToolStripMenuItem.Text = "Aluno";
            this.alunoToolStripMenuItem.Click += new System.EventHandler(this.alunoToolStripMenuItem_Click);
            // 
            // professoresToolStripMenuItem
            // 
            this.professoresToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("professoresToolStripMenuItem.Image")));
            this.professoresToolStripMenuItem.Name = "professoresToolStripMenuItem";
            this.professoresToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.professoresToolStripMenuItem.Text = "Professor";
            this.professoresToolStripMenuItem.Click += new System.EventHandler(this.professoresToolStripMenuItem_Click);
            // 
            // livrosToolStripMenuItem
            // 
            this.livrosToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("livrosToolStripMenuItem.Image")));
            this.livrosToolStripMenuItem.Name = "livrosToolStripMenuItem";
            this.livrosToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.livrosToolStripMenuItem.Text = "Livro";
            this.livrosToolStripMenuItem.Click += new System.EventHandler(this.livrosToolStripMenuItem_Click);
            // 
            // tabletToolStripMenuItem
            // 
            this.tabletToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("tabletToolStripMenuItem.Image")));
            this.tabletToolStripMenuItem.Name = "tabletToolStripMenuItem";
            this.tabletToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.tabletToolStripMenuItem.Text = "Tablet";
            this.tabletToolStripMenuItem.Click += new System.EventHandler(this.tabletToolStripMenuItem_Click);
            // 
            // filmesToolStripMenuItem
            // 
            this.filmesToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("filmesToolStripMenuItem.Image")));
            this.filmesToolStripMenuItem.Name = "filmesToolStripMenuItem";
            this.filmesToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.filmesToolStripMenuItem.Text = "Filme";
            this.filmesToolStripMenuItem.Click += new System.EventHandler(this.filmesToolStripMenuItem_Click);
            // 
            // computadorToolStripMenuItem1
            // 
            this.computadorToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("computadorToolStripMenuItem1.Image")));
            this.computadorToolStripMenuItem1.Name = "computadorToolStripMenuItem1";
            this.computadorToolStripMenuItem1.Size = new System.Drawing.Size(142, 22);
            this.computadorToolStripMenuItem1.Text = "Computador";
            this.computadorToolStripMenuItem1.Click += new System.EventHandler(this.computadorToolStripMenuItem1_Click_1);
            // 
            // pesquisarToolStripMenuItem
            // 
            this.pesquisarToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.alunoToolStripMenuItem1,
            this.professorToolStripMenuItem1,
            this.livroToolStripMenuItem,
            this.tabletToolStripMenuItem1,
            this.filmeToolStripMenuItem});
            this.pesquisarToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("pesquisarToolStripMenuItem.Image")));
            this.pesquisarToolStripMenuItem.Name = "pesquisarToolStripMenuItem";
            this.pesquisarToolStripMenuItem.Size = new System.Drawing.Size(69, 55);
            this.pesquisarToolStripMenuItem.Text = "Pesquisar";
            this.pesquisarToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // alunoToolStripMenuItem1
            // 
            this.alunoToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("alunoToolStripMenuItem1.Image")));
            this.alunoToolStripMenuItem1.Name = "alunoToolStripMenuItem1";
            this.alunoToolStripMenuItem1.Size = new System.Drawing.Size(123, 22);
            this.alunoToolStripMenuItem1.Text = "Aluno";
            this.alunoToolStripMenuItem1.Click += new System.EventHandler(this.alunoToolStripMenuItem1_Click);
            // 
            // professorToolStripMenuItem1
            // 
            this.professorToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("professorToolStripMenuItem1.Image")));
            this.professorToolStripMenuItem1.Name = "professorToolStripMenuItem1";
            this.professorToolStripMenuItem1.Size = new System.Drawing.Size(123, 22);
            this.professorToolStripMenuItem1.Text = "Professor";
            this.professorToolStripMenuItem1.Click += new System.EventHandler(this.professorToolStripMenuItem1_Click);
            // 
            // livroToolStripMenuItem
            // 
            this.livroToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("livroToolStripMenuItem.Image")));
            this.livroToolStripMenuItem.Name = "livroToolStripMenuItem";
            this.livroToolStripMenuItem.Size = new System.Drawing.Size(123, 22);
            this.livroToolStripMenuItem.Text = "Livro";
            this.livroToolStripMenuItem.Click += new System.EventHandler(this.livroToolStripMenuItem_Click);
            // 
            // tabletToolStripMenuItem1
            // 
            this.tabletToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("tabletToolStripMenuItem1.Image")));
            this.tabletToolStripMenuItem1.Name = "tabletToolStripMenuItem1";
            this.tabletToolStripMenuItem1.Size = new System.Drawing.Size(123, 22);
            this.tabletToolStripMenuItem1.Text = "Tablet";
            this.tabletToolStripMenuItem1.Click += new System.EventHandler(this.tabletToolStripMenuItem1_Click);
            // 
            // filmeToolStripMenuItem
            // 
            this.filmeToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("filmeToolStripMenuItem.Image")));
            this.filmeToolStripMenuItem.Name = "filmeToolStripMenuItem";
            this.filmeToolStripMenuItem.Size = new System.Drawing.Size(123, 22);
            this.filmeToolStripMenuItem.Text = "Filme";
            this.filmeToolStripMenuItem.Click += new System.EventHandler(this.filmeToolStripMenuItem_Click);
            // 
            // movimentosToolStripMenuItem
            // 
            this.movimentosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.requisiçãoToolStripMenuItem,
            this.relatoriosToolStripMenuItem});
            this.movimentosToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("movimentosToolStripMenuItem.Image")));
            this.movimentosToolStripMenuItem.Name = "movimentosToolStripMenuItem";
            this.movimentosToolStripMenuItem.Size = new System.Drawing.Size(86, 55);
            this.movimentosToolStripMenuItem.Text = "Movimentos";
            this.movimentosToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // requisiçãoToolStripMenuItem
            // 
            this.requisiçãoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.livrosToolStripMenuItem1,
            this.computadoresToolStripMenuItem,
            this.tabletsToolStripMenuItem});
            this.requisiçãoToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("requisiçãoToolStripMenuItem.Image")));
            this.requisiçãoToolStripMenuItem.Name = "requisiçãoToolStripMenuItem";
            this.requisiçãoToolStripMenuItem.Size = new System.Drawing.Size(200, 42);
            this.requisiçãoToolStripMenuItem.Text = "Requisição";
            // 
            // livrosToolStripMenuItem1
            // 
            this.livrosToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("livrosToolStripMenuItem1.Image")));
            this.livrosToolStripMenuItem1.Name = "livrosToolStripMenuItem1";
            this.livrosToolStripMenuItem1.Size = new System.Drawing.Size(153, 22);
            this.livrosToolStripMenuItem1.Text = "Livros";
            this.livrosToolStripMenuItem1.Click += new System.EventHandler(this.livrosToolStripMenuItem1_Click);
            // 
            // computadoresToolStripMenuItem
            // 
            this.computadoresToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("computadoresToolStripMenuItem.Image")));
            this.computadoresToolStripMenuItem.Name = "computadoresToolStripMenuItem";
            this.computadoresToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.computadoresToolStripMenuItem.Text = "Computadores";
            this.computadoresToolStripMenuItem.Click += new System.EventHandler(this.computadoresToolStripMenuItem_Click);
            // 
            // tabletsToolStripMenuItem
            // 
            this.tabletsToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("tabletsToolStripMenuItem.Image")));
            this.tabletsToolStripMenuItem.Name = "tabletsToolStripMenuItem";
            this.tabletsToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.tabletsToolStripMenuItem.Text = "Tablets";
            this.tabletsToolStripMenuItem.Click += new System.EventHandler(this.tabletsToolStripMenuItem_Click);
            // 
            // relatoriosToolStripMenuItem
            // 
            this.relatoriosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.livrosToolStripMenuItem2,
            this.computadoresToolStripMenuItem1,
            this.tabletsToolStripMenuItem1});
            this.relatoriosToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("relatoriosToolStripMenuItem.Image")));
            this.relatoriosToolStripMenuItem.Name = "relatoriosToolStripMenuItem";
            this.relatoriosToolStripMenuItem.Size = new System.Drawing.Size(200, 42);
            this.relatoriosToolStripMenuItem.Text = "Devolução";
            this.relatoriosToolStripMenuItem.Click += new System.EventHandler(this.relatoriosToolStripMenuItem_Click);
            // 
            // livrosToolStripMenuItem2
            // 
            this.livrosToolStripMenuItem2.Image = ((System.Drawing.Image)(resources.GetObject("livrosToolStripMenuItem2.Image")));
            this.livrosToolStripMenuItem2.Name = "livrosToolStripMenuItem2";
            this.livrosToolStripMenuItem2.Size = new System.Drawing.Size(200, 42);
            this.livrosToolStripMenuItem2.Text = "Livros";
            this.livrosToolStripMenuItem2.Click += new System.EventHandler(this.livrosToolStripMenuItem2_Click_1);
            // 
            // computadoresToolStripMenuItem1
            // 
            this.computadoresToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("computadoresToolStripMenuItem1.Image")));
            this.computadoresToolStripMenuItem1.Name = "computadoresToolStripMenuItem1";
            this.computadoresToolStripMenuItem1.Size = new System.Drawing.Size(200, 42);
            this.computadoresToolStripMenuItem1.Text = "Computadores";
            this.computadoresToolStripMenuItem1.Click += new System.EventHandler(this.computadoresToolStripMenuItem1_Click);
            // 
            // tabletsToolStripMenuItem1
            // 
            this.tabletsToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("tabletsToolStripMenuItem1.Image")));
            this.tabletsToolStripMenuItem1.Name = "tabletsToolStripMenuItem1";
            this.tabletsToolStripMenuItem1.Size = new System.Drawing.Size(200, 42);
            this.tabletsToolStripMenuItem1.Text = "Tablets";
            this.tabletsToolStripMenuItem1.Click += new System.EventHandler(this.tabletsToolStripMenuItem1_Click);
            // 
            // relatórioToolStripMenuItem
            // 
            this.relatórioToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.alunoToolStripMenuItem2,
            this.professorToolStripMenuItem,
            this.livroToolStripMenuItem1,
            this.tabletToolStripMenuItem2,
            this.computadorToolStripMenuItem,
            this.filmeToolStripMenuItem1});
            this.relatórioToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("relatórioToolStripMenuItem.Image")));
            this.relatórioToolStripMenuItem.Name = "relatórioToolStripMenuItem";
            this.relatórioToolStripMenuItem.Size = new System.Drawing.Size(66, 55);
            this.relatórioToolStripMenuItem.Text = "Relatório";
            this.relatórioToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // alunoToolStripMenuItem2
            // 
            this.alunoToolStripMenuItem2.Image = ((System.Drawing.Image)(resources.GetObject("alunoToolStripMenuItem2.Image")));
            this.alunoToolStripMenuItem2.Name = "alunoToolStripMenuItem2";
            this.alunoToolStripMenuItem2.Size = new System.Drawing.Size(200, 42);
            this.alunoToolStripMenuItem2.Text = "Aluno";
            this.alunoToolStripMenuItem2.Click += new System.EventHandler(this.alunoToolStripMenuItem2_Click);
            // 
            // professorToolStripMenuItem
            // 
            this.professorToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("professorToolStripMenuItem.Image")));
            this.professorToolStripMenuItem.Name = "professorToolStripMenuItem";
            this.professorToolStripMenuItem.Size = new System.Drawing.Size(200, 42);
            this.professorToolStripMenuItem.Text = "Professor";
            this.professorToolStripMenuItem.Click += new System.EventHandler(this.professorToolStripMenuItem_Click);
            // 
            // livroToolStripMenuItem1
            // 
            this.livroToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("livroToolStripMenuItem1.Image")));
            this.livroToolStripMenuItem1.Name = "livroToolStripMenuItem1";
            this.livroToolStripMenuItem1.Size = new System.Drawing.Size(200, 42);
            this.livroToolStripMenuItem1.Text = "Livro";
            this.livroToolStripMenuItem1.Click += new System.EventHandler(this.livroToolStripMenuItem1_Click);
            // 
            // tabletToolStripMenuItem2
            // 
            this.tabletToolStripMenuItem2.Image = ((System.Drawing.Image)(resources.GetObject("tabletToolStripMenuItem2.Image")));
            this.tabletToolStripMenuItem2.Name = "tabletToolStripMenuItem2";
            this.tabletToolStripMenuItem2.Size = new System.Drawing.Size(200, 42);
            this.tabletToolStripMenuItem2.Text = "Tablet";
            this.tabletToolStripMenuItem2.Click += new System.EventHandler(this.tabletToolStripMenuItem2_Click);
            // 
            // computadorToolStripMenuItem
            // 
            this.computadorToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("computadorToolStripMenuItem.Image")));
            this.computadorToolStripMenuItem.Name = "computadorToolStripMenuItem";
            this.computadorToolStripMenuItem.Size = new System.Drawing.Size(200, 42);
            this.computadorToolStripMenuItem.Text = "Computador";
            this.computadorToolStripMenuItem.Click += new System.EventHandler(this.computadorToolStripMenuItem_Click);
            // 
            // filmeToolStripMenuItem1
            // 
            this.filmeToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("filmeToolStripMenuItem1.Image")));
            this.filmeToolStripMenuItem1.Name = "filmeToolStripMenuItem1";
            this.filmeToolStripMenuItem1.Size = new System.Drawing.Size(200, 42);
            this.filmeToolStripMenuItem1.Text = "Filme";
            this.filmeToolStripMenuItem1.Click += new System.EventHandler(this.filmeToolStripMenuItem1_Click_1);
            // 
            // ferramentasToolStripMenuItem
            // 
            this.ferramentasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.backupToolStripMenuItem,
            this.tecnesaToolStripMenuItem,
            this.emailToolStripMenuItem});
            this.ferramentasToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("ferramentasToolStripMenuItem.Image")));
            this.ferramentasToolStripMenuItem.Name = "ferramentasToolStripMenuItem";
            this.ferramentasToolStripMenuItem.Size = new System.Drawing.Size(84, 55);
            this.ferramentasToolStripMenuItem.Text = "Ferramentas";
            this.ferramentasToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // backupToolStripMenuItem
            // 
            this.backupToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("backupToolStripMenuItem.Image")));
            this.backupToolStripMenuItem.Name = "backupToolStripMenuItem";
            this.backupToolStripMenuItem.Size = new System.Drawing.Size(149, 22);
            this.backupToolStripMenuItem.Text = "Backup";
            this.backupToolStripMenuItem.Click += new System.EventHandler(this.backupToolStripMenuItem_Click);
            // 
            // tecnesaToolStripMenuItem
            // 
            this.tecnesaToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("tecnesaToolStripMenuItem.Image")));
            this.tecnesaToolStripMenuItem.Name = "tecnesaToolStripMenuItem";
            this.tecnesaToolStripMenuItem.Size = new System.Drawing.Size(149, 22);
            this.tecnesaToolStripMenuItem.Text = "Apoio Técnico";
            this.tecnesaToolStripMenuItem.Click += new System.EventHandler(this.tecnesaToolStripMenuItem_Click);
            // 
            // emailToolStripMenuItem
            // 
            this.emailToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("emailToolStripMenuItem.Image")));
            this.emailToolStripMenuItem.Name = "emailToolStripMenuItem";
            this.emailToolStripMenuItem.Size = new System.Drawing.Size(149, 22);
            this.emailToolStripMenuItem.Text = "Email";
            this.emailToolStripMenuItem.Click += new System.EventHandler(this.emailToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripMenuItem1.Image")));
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(74, 55);
            this.toolStripMenuItem1.Text = "Definições";
            this.toolStripMenuItem1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // ajudaToolStripMenuItem
            // 
            this.ajudaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.websiteToolStripMenuItem,
            this.contactoToolStripMenuItem,
            this.sugestõesToolStripMenuItem});
            this.ajudaToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("ajudaToolStripMenuItem.Image")));
            this.ajudaToolStripMenuItem.Name = "ajudaToolStripMenuItem";
            this.ajudaToolStripMenuItem.Size = new System.Drawing.Size(50, 55);
            this.ajudaToolStripMenuItem.Text = "Ajuda";
            this.ajudaToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // websiteToolStripMenuItem
            // 
            this.websiteToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("websiteToolStripMenuItem.Image")));
            this.websiteToolStripMenuItem.Name = "websiteToolStripMenuItem";
            this.websiteToolStripMenuItem.Size = new System.Drawing.Size(127, 22);
            this.websiteToolStripMenuItem.Text = "Website";
            this.websiteToolStripMenuItem.Click += new System.EventHandler(this.websiteToolStripMenuItem_Click);
            // 
            // contactoToolStripMenuItem
            // 
            this.contactoToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("contactoToolStripMenuItem.Image")));
            this.contactoToolStripMenuItem.Name = "contactoToolStripMenuItem";
            this.contactoToolStripMenuItem.Size = new System.Drawing.Size(127, 22);
            this.contactoToolStripMenuItem.Text = "Contacto";
            this.contactoToolStripMenuItem.Click += new System.EventHandler(this.contactoToolStripMenuItem_Click);
            // 
            // sugestõesToolStripMenuItem
            // 
            this.sugestõesToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("sugestõesToolStripMenuItem.Image")));
            this.sugestõesToolStripMenuItem.Name = "sugestõesToolStripMenuItem";
            this.sugestõesToolStripMenuItem.Size = new System.Drawing.Size(127, 22);
            this.sugestõesToolStripMenuItem.Text = "Sugestões";
            this.sugestõesToolStripMenuItem.Click += new System.EventHandler(this.sugestõesToolStripMenuItem_Click);
            // 
            // terminarSessãoToolStripMenuItem
            // 
            this.terminarSessãoToolStripMenuItem.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.terminarSessãoToolStripMenuItem.Name = "terminarSessãoToolStripMenuItem";
            this.terminarSessãoToolStripMenuItem.Size = new System.Drawing.Size(102, 55);
            this.terminarSessãoToolStripMenuItem.Text = "Terminar sessão";
            this.terminarSessãoToolStripMenuItem.Click += new System.EventHandler(this.terminarSessãoToolStripMenuItem_Click);
            // 
            // menuStrip2
            // 
            this.menuStrip2.BackColor = System.Drawing.Color.Transparent;
            this.menuStrip2.ImageScalingSize = new System.Drawing.Size(22, 22);
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sairToolStripMenuItem1,
            this.minimizarToolStripMenuItem1,
            this.menuPrincipalToolStripMenuItem});
            this.menuStrip2.Location = new System.Drawing.Point(0, 0);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Size = new System.Drawing.Size(1360, 30);
            this.menuStrip2.TabIndex = 1;
            this.menuStrip2.Text = "menuStrip2";
            this.menuStrip2.Visible = false;
            this.menuStrip2.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip2_ItemClicked);
            // 
            // sairToolStripMenuItem1
            // 
            this.sairToolStripMenuItem1.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.sairToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("sairToolStripMenuItem1.Image")));
            this.sairToolStripMenuItem1.Name = "sairToolStripMenuItem1";
            this.sairToolStripMenuItem1.Size = new System.Drawing.Size(34, 26);
            this.sairToolStripMenuItem1.Click += new System.EventHandler(this.sairToolStripMenuItem1_Click);
            // 
            // minimizarToolStripMenuItem1
            // 
            this.minimizarToolStripMenuItem1.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.minimizarToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("minimizarToolStripMenuItem1.Image")));
            this.minimizarToolStripMenuItem1.Name = "minimizarToolStripMenuItem1";
            this.minimizarToolStripMenuItem1.Size = new System.Drawing.Size(34, 26);
            this.minimizarToolStripMenuItem1.Click += new System.EventHandler(this.minimizarToolStripMenuItem1_Click);
            // 
            // menuPrincipalToolStripMenuItem
            // 
            this.menuPrincipalToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("menuPrincipalToolStripMenuItem.Image")));
            this.menuPrincipalToolStripMenuItem.Name = "menuPrincipalToolStripMenuItem";
            this.menuPrincipalToolStripMenuItem.Size = new System.Drawing.Size(130, 26);
            this.menuPrincipalToolStripMenuItem.Text = " | Menu Principal";
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.Filter = "\"Backup Srbe (*.BkSrbe)|*.BkSrbe|All files (*.*)|*.*\"";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(1252, 716);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "Versão 1.0";
            // 
            // Frm_MenuPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1360, 700);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.menuStrip2);
            this.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Frm_MenuPrincipal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sistema de Requisição de Bibliotecas Escolares";
            this.Load += new System.EventHandler(this.Frm_MenuPrincipal_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem registarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pesquisarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem movimentosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem relatórioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ferramentasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem backupToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem alunoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem professoresToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem livrosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tabletToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem alunoToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem livroToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tabletToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem livroToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem tabletToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem computadorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tecnesaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ajudaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem websiteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sugestõesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem filmesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem computadorToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem filmeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem terminarSessãoToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem sairToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem minimizarToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem menuPrincipalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.ToolStripMenuItem alunoToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem professorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem filmeToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem professorToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem requisiçãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem contactoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem livrosToolStripMenuItem1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripMenuItem emailToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem computadoresToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tabletsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem relatoriosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem livrosToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem computadoresToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem tabletsToolStripMenuItem1;
    }
}