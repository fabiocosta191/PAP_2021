﻿param($installPath, $toolsPath, $package, $project)

$DTE.ItemOperations.Navigate("http://go.microsoft.com/fwlink/?LinkId=834967")
